import pandas as pd
from sentence_transformers import SentenceTransformer
from neo4j import GraphDatabase

cluster_summary = pd.read_csv(r"C:\Users\muthuvu\Videos\10X-MLE-master\notebook\output_clusters_single\final_cluster_summary_df.csv")
final_cluster_pd = pd.read_csv(r"C:\Users\muthuvu\Videos\10X-MLE-master\notebook\output_clusters_single\final_cluster_pd.csv")

em = SentenceTransformer("all-mpnet-base-v2")

driver = GraphDatabase.driver("neo4j://localhost:7687", auth=("neo4j", "12345678"))

with driver.session() as session:
    for _, row in final_cluster_pd.iterrows():
        cluster_id = row["cluster"]
        cluster_size = row.get("cluster_size", None)
        summary = row["summary"]

        # Parse device/category from cluster_mode1 string
        l = row["cluster_mode1"].strip("[]").replace("'", "").split()
        device_os = l[1] if len(l) > 1 else None
        category = l[3] if len(l) > 3 else None

        # Compute embedding vector for semantic search
        embedding = em.encode(summary).tolist()

        session.run(
            """
            MERGE (cl:Cluster {
                cluster_id: $id
            })
            SET cl.size = $size,
                cl.summary = $summary,
                cl.device_os = $device_os,
                cl.category = $category,
                cl.embedding = $embedding
            """,
            id=cluster_id,
            size=cluster_size,
            summary=summary,
            device_os=device_os,
            category=category,
            embedding=embedding,
        )

with driver.session() as session:
    for cluster_id in final_cluster_pd["cluster"].unique():
        # get up to 10 muids for this cluster
        sample_muids = (
            final_cluster_pd[final_cluster_pd["cluster"] == cluster_id]["muid"].to_list()[:10]
        )

        for cust_id in sample_muids:
            session.run(
                """
                MERGE (c:Customer {id: $cust_id})
                WITH c
                MATCH (cl:Cluster {cluster_id: $cluster_id})
                MERGE (c)-[:IN_CLUSTER]->(cl)
                """,
                cust_id=cust_id,
                cluster_id=cluster_id
            )
