from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import json 
from neo4j import GraphDatabase
import pandas as pd
from sentence_transformers import SentenceTransformer
import uvicorn

app = FastAPI()
driver = GraphDatabase.driver("neo4j://localhost:7687", auth=("neo4j", "12345678"))
em = SentenceTransformer("all-mpnet-base-v2")

def semantic_search(query_text, k=5, device_os=None, category=None):
    query_embedding = em.encode(query_text).tolist()

    if device_os and category:
        with driver.session() as session:
            result = session.run(
                """
                CALL db.index.vector.queryNodes('cluster_summary_index', $k, $query_embedding)
                YIELD node, score
                WHERE node.device_os = "ios" and node.category = "coffee"
                OPTIONAL MATCH (c:Customer)-[:IN_CLUSTER]->(node)
                WITH node, score, collect(c.id)[0..10] AS sample_muids
                RETURN node.cluster_id AS cluster_id,
                    node.summary AS summary,
                    node.size AS size,
                    sample_muids,
                    score
                """,
                query_embedding=query_embedding,
                k=k
            )
            records = [dict(r) for r in result]
            json_str = json.dumps(records, indent=2)
            
            with open("result.json", "w") as f:
                f.write(json_str)

            return records

    else:
        with driver.session() as session:
            result = session.run(
                """
                CALL db.index.vector.queryNodes('cluster_summary_index', $k, $query_embedding)
                YIELD node, score
                OPTIONAL MATCH (c:Customer)-[:IN_CLUSTER]->(node)
                WITH node, score, collect(c.id)[0..10] AS sample_muids
                RETURN node.cluster_id AS cluster_id,
                    node.summary AS summary,
                    node.size AS size,
                    sample_muids,
                    score
                """,
                query_embedding=query_embedding,
                k=k
            )

            records = [dict(r) for r in result]
            json_str = json.dumps(records, indent=2)
            
            with open("result.json", "w") as f:
                f.write(json_str)
            
            return records

class QueryRequest(BaseModel):
    query: str
    device_os: str = None
    category: str = None
    top_k: int = 5

@app.post("/ask")
def ask_rag(request: QueryRequest):
    try:
        answer = semantic_search(
            request.query.lower(),
            k=request.top_k,
            device_os=request.device_os,
            category=request.category
        )
        return {"query": request.query, "answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)