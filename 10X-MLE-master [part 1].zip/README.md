# Graph RAG
RAG application to find users who follow similar purchase pattern given a query pattern
Utilized Neo4j + sentence-transformers for semantic search

